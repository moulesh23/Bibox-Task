/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */


	//Assuming the data type to be character array as couldn't get to know the required data type from the question clearly.
	//Assuming the data is taken statically and not obtained dynamically from peripheral like (UART)
	char inData[]= { 'S','E','T','O','A','I','P','O','O','O','O','O','P','o','{','1','0','1','}','d','2','100','=','o','{','4','0','100','}','R','S','T'};
		//Possible error in the above data as the value '100' exceeds the maximum allowed size of character variable, leading to truncation.
	uint8_t opFlag=0, loopFlag=0;
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */

	GPIO_TypeDef  *GPIOm;
	
	do
	{		
		if(inData[0]=='S' && inData[1]=='E' && inData[2]=='T')
				{
						for(uint8_t i=3; i<=12;++i)
						{	
							switch(i)
							{
								case 3: GPIOm=GPIOA; break;
								case 4: GPIOm=GPIOB; break;
								case 5: GPIOm=GPIOC; break;
								case 6: GPIOm=GPIOD; break;
								case 7: GPIOm=GPIOE; break;
								case 8: GPIOm=GPIOF; break;
								case 9: GPIOm=GPIOG; break;
								case 10: GPIOm=GPIOH; break;
								case 11: GPIOm=GPIOI; break;
								//case 12: GPIOm=GPIOJ; break;
								// Board supports only 9 GPIOs. Hence commenting out the initialisation for the 10th port. 
							}
							// Assuming the Pin 0 is used in each port
							if(inData[i]=='O')
								GPIOm->MODER=MODE_OUTPUT;
							else if(inData[i]=='A')
								GPIOm->MODER=MODE_ANALOG;
							else if(inData[i]=='I')
								GPIOm->MODER=MODE_INPUT;
							else if(inData[i]=='P')
								GPIOm->MODER=MODE_AF;
						}
					}
				if(inData[13]=='o')
				{
							switch(inData[15])
							{
								case 1: GPIOm=GPIOA; break;
								case 2: GPIOm=GPIOB; break;
								case 3: GPIOm=GPIOC; break;
								case 4: GPIOm=GPIOD; break;
								case 5: GPIOm=GPIOE; break;
								case 6: GPIOm=GPIOF; break;
								case 7: GPIOm=GPIOG; break;
								case 8: GPIOm=GPIOH; break;
								case 9: GPIOm=GPIOI; break;
								//case 10: GPIOm=GPIOJ; break;
							}
							uint16_t tmp=inData[17];
							tmp<<=8;
							tmp&=0xFF00;
							tmp|=inData[16];
							if(tmp==0x01)
							{
								GPIOm->ODR=0x01;
							}
							else if(tmp==0x00)
							{
								GPIOm->ODR=0x00;
							}
						}

					if(inData[19]=='d')
					{
						switch(inData[20])
						{
								case 1: GPIOm=GPIOA; break;
								case 2: GPIOm=GPIOB; break;
								case 3: GPIOm=GPIOC; break;
								case 4: GPIOm=GPIOD; break;
								case 5: GPIOm=GPIOE; break;
								case 6: GPIOm=GPIOF; break;
								case 7: GPIOm=GPIOG; break;
								case 8: GPIOm=GPIOH; break;
								case 9: GPIOm=GPIOI; break;
								//case 10: GPIOm=GPIOJ; break;
						}
						if(inData[22]=='=')
						{
							if(GPIOm->IDR==inData[21])
							{
								opFlag=1;
							}
							else if(inData[22]=='<')
							{
								if(GPIOm->IDR<inData[21])
								{
									opFlag=1;
								}
							}
							//Assuming all other comparison functions are implemented like wise
						}
						if(opFlag==1)
						{
							//pwm impl
							GPIOm->AFR[0]|=0x0001; //Setting the alternate functionality to timer (TIM2)
							//Initialise the corresponding timer in PWM Mode with appropriate Configuration
							// Set the desired Duty Cycle by modifying the pre-scaler and counter period
							opFlag=0;
						}
					}
					if(inData[29]=='R' && inData[30] == 'S' && inData[31] == 'T')
					{
						loopFlag=1;
					}
					else
					{
						loopFlag=0;
					}
				}while(loopFlag==1);
				
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV8;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOE_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOG_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOI_CLK_ENABLE();
	//HAL_RCC_GPIOJ_CLK_ENABLE();

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
